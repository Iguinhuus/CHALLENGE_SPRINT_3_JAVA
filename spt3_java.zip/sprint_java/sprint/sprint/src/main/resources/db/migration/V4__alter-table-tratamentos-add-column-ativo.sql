alter table tratamentos add ativo tinyint;
update tratamentos set ativo =1;