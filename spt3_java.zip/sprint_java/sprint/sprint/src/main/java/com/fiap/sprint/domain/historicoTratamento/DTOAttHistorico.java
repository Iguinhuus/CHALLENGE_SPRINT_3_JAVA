package com.fiap.sprint.domain.historicoTratamento;


import jakarta.validation.constraints.NotNull;

public record DTOAttHistorico(@NotNull Long id, String observacao) {






}
