package com.fiap.sprint.domain.recomendacao;


import jakarta.validation.constraints.NotNull;

public record DTOAttRecomendacao(@NotNull Long id, String motivo) {






}
