package com.fiap.sprint.domain.tratamento;

public enum Tipo {
    CANAL,
    EMERGENCIAL,
    PREVENTIVO,
    ESTETICA,
    PROTESE,
    IMPLANTE,
    ORTODONTIA,
    RESTAURADOR,
    ENDODONTIA,
    PERIODONTIA

}
