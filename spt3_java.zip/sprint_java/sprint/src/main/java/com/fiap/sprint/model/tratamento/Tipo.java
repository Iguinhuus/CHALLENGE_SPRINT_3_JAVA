package com.fiap.sprint.model.tratamento;

public enum Tipo {
    CANAL,
    EMERGENCIAL,
    PREVENTIVO,
    ESTETICA,
    PROTESE,
    IMPLANTE,
    ORTODONTIA,
    RESTAURADOR,
    ENDODONTIA,
    PERIODONTIA

}
