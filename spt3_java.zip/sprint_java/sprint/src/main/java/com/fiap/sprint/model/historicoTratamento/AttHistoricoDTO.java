package com.fiap.sprint.model.historicoTratamento;


import jakarta.validation.constraints.NotNull;

public record AttHistoricoDTO(@NotNull Long id, String observacao) {






}
