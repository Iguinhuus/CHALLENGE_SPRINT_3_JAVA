package com.fiap.sprint.model.recomendacao;


import jakarta.validation.constraints.NotNull;

public record AttRecomendacaoDTO(@NotNull Long id, String motivo) {






}
