package com.fiap.sprint.model.paciente;

public enum Genero {
    MASCULINO,
    FEMININO,
    NAO_BINARIO,
    GENERO_FLUIDO,
    OUTRO,
    PREFIRO_NAO_DIZER
}
